<?php class Test {
	function __construct() {}
	function call() {
		$view = new VTest('Test!!');
		$view->render();
	}
}?>